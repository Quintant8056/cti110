import turtle

wn = turtle.Screen()
alex = turtle.Turtle()

#alex.forward(50)
#alex.left(90)
i = 1
t = 1
while i < 5:
  alex.forward(50)
  alex.left(90)
  i += 1

while t < 4:
  alex.forward(60)
  alex.left(120)
  t += 1

alex.pencolor("red")
alex.pensize(5)

alex.penup()
alex.forward(100)    
alex.pendown()
alex.forward(50)
alex.backward(25)
alex.right(90)
alex.forward(50)
alex.left(90)
alex.penup()
alex.forward(60)
alex.pendown()
alex.circle(30)
alex.penup()
alex.forward(20)
alex.pendown()
alex.left(120)
alex.forward(20)
alex.penup()
alex.forward(100)
wn.mainloop()
